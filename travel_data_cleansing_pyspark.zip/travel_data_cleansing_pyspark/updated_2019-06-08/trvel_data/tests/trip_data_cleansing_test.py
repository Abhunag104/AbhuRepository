from pyspark.sql import SparkSession, DataFrame
from spark import trip_data_cleansing

INPUT_PATH = "../input/test_data.json"


def test_join_segment():
    input_segments = [['AMS', 'LHR'], ['LHR', 'EZE']]
    result = "AMS-LHR-EZE"
    assert result == trip_data_cleansing.join_segment(input_segments)
    input_segments_2 = [['AMS', 'BOM']]
    result_2 = "AMS-BOM"
    assert result_2 == trip_data_cleansing.join_segment(input_segments_2)


# joining to sequential legs
def test_join_leg():
    input_leg = ['AMS-LHR-EZE', 'EZE-LHR-AMS-EZE-LHR-AMS']
    result = "AMS-LHR-EZE-LHR-AMS-EZE-LHR-AMS"
    assert result == trip_data_cleansing.join_leg(input_leg)
    input_leg_2 = ['AMS-BOM']
    result_2 = "AMS-BOM"
    assert result_2 == trip_data_cleansing.join_leg(input_leg_2)


def test_empty_join_segment():
    input_segments = [[], []]
    result = ""
    assert result == trip_data_cleansing.join_segment(input_segments)


def test_empty_leg_segment():
    input_segments = []
    result = ""
    assert result == trip_data_cleansing.join_leg(input_segments)


# test to check if 1 wrong Itinerary filtering out correctly
def test_data_cleansing():
    spark = SparkSession.builder\
        .appName("data_cleansing").enableHiveSupport().getOrCreate()
    result_df = trip_data_cleansing.data_cleansing(spark=spark, input_path=INPUT_PATH)
    assert type(result_df) == DataFrame
    assert result_df.count() == 1