import argparse
from pyspark.sql import SparkSession
from pyspark.sql.types import StringType, BooleanType
from pyspark.sql.functions import struct, when
from pyspark.sql import functions as f


# join_segment and join_leg blocks used to create own Itinerary
def join_segment(segments):
    joined_seg = ""
    for segment in segments:
        if len(joined_seg) == 0:
            joined_seg = joined_seg + "-".join(segment)
        else:
            for seg in segment:
                check_dest = joined_seg.split('-')[-1]
                if seg != check_dest:
                    joined_seg = "-".join([joined_seg, seg])
    return joined_seg


def join_leg(legs):
    joined_leg = ""
    for leg in legs:
        if len(joined_leg) == 0:
            joined_leg = leg
        else:
            check_dest = joined_leg.split('-')[-1]
            check_source = leg.split('-')[0]
            if check_dest == check_source:
                joined_leg = joined_leg + "-" + "-".join(leg.split('-')[1:])
            else:
                joined_leg = joined_leg + "-" + leg
    return joined_leg


def one_way_or_return_check(itinerary, one_way_or_return):
    source = itinerary.split('-')[0]
    destination = itinerary.split('-')[-1]
    if (source == destination and one_way_or_return == "Return") or (
            source != destination and one_way_or_return == "One Way"):
        result = True
    else:
        result = False
    return result


# task-1) creating own Itinerary from departure and arrival information
#      2)matching created Itinerary with Itinerary in data
def data_cleansing(spark, input_path):

    df = spark.read.option("multiline", "true").json(input_path)
    df = df.dropDuplicates(['TripId', 'Leg', 'SegmentOrder']).repartition(10, df.TripId)  # data deduplication

    join_segment_udf = f.UserDefinedFunction(join_segment, StringType())
    join_leg_udf = f.UserDefinedFunction(join_leg, StringType())
    one_way_or_return_check_udf = f.UserDefinedFunction(
        one_way_or_return_check, BooleanType())

    seg_grouped_df = df.groupBy("Leg", "TripId").agg(
        f.collect_list(struct("DepartureAirport", "ArrivalAirport")
                       ).alias('source_dest'))

    seg_grouped_df = seg_grouped_df.orderBy("Leg")

    segment_joined_df = seg_grouped_df \
        .select(seg_grouped_df['TripId'], seg_grouped_df['Leg'],
                seg_grouped_df['source_dest'],
                join_segment_udf(seg_grouped_df['source_dest'])
                .alias('seg_joined')).cache()

    leg_grouped_df = segment_joined_df.groupBy("TripId") \
        .agg(f.collect_list("seg_joined").alias('leg_source_dest')).cache()

    leg_joined_df = leg_grouped_df \
        .select(leg_grouped_df['TripId'],
                leg_grouped_df['leg_source_dest'],
                join_leg_udf(leg_grouped_df['leg_source_dest'])
                .alias('resulting_itinerary'))

    leg_joined_df.cache()

    joined_df = df.join(leg_joined_df, df.TripId == leg_joined_df.TripId). \
        select(df['TripId'], df['Itinerary'],
               leg_joined_df['resulting_itinerary'],
               df['OneWayOrReturn']).dropDuplicates(['TripId'])

    joined_df = joined_df \
        .withColumn('OneWayOrReturn_check',
                    one_way_or_return_check_udf(
                        joined_df['resulting_itinerary'],
                        joined_df['OneWayOrReturn'])
                    )

    # getting reason of wrong record either Itinerary or OneWayOrReturn
    final_df = joined_df \
        .withColumn('Reason',
                    when(joined_df.Itinerary != joined_df.resulting_itinerary, 'Itinerary')
                    .when((joined_df.Itinerary == joined_df.resulting_itinerary)
                          & (~ joined_df.OneWayOrReturn_check), 'OneWayOrReturn')
                    .otherwise('Perfect'))

    final_df = final_df.filter(final_df.Reason != 'Perfect') \
        .select('TripId', 'Reason')

    return final_df

# writing erroneous Itinerary information into CSV file
def _write_results(result_df, output_path):

    df = (result_df.repartition(1)
          .write.mode('overwrite')
          .format('com.databricks.spark.csv'))

    df.save(output_path)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(
        description='Spark job to clean Travix trip data'
    )

    parser.add_argument(
        '--input-path', action='store', type=str,
        dest='input_path', required=True,
        help='input path for the data'
    )

    parser.add_argument(
        '--output-path', action='store', type=str,
        dest='output_path', required=True,
        help='output path for the clean data'
    )

    args = parser.parse_args()
    app_name = 'data cleansing job'
    spark = SparkSession.builder \
        .appName(app_name) \
        .enableHiveSupport() \
        .getOrCreate()

    spark.sparkContext.setLogLevel("WARN")

    result_df = data_cleansing(spark, input_path=args.input_path)
    _write_results(result_df=result_df, output_path=args.output_path)