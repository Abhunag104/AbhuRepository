from airflow import DAG
from airflow.operators.python_operator import PythonOperator
from airflow.operators.mysql_operator import MySqlOperator, MySqlHook
from datetime import datetime, timedelta


default_args = {
    'owner': 'airflow',
    'start_date': datetime(2019, 6, 2),
    'retries': 1,
    'retry_delay': timedelta(seconds=60)
}

AIRFLOW_TABLE_NAME = 'airflow_tables_record_count'
MYSQL_CONN_ID = 'mysql_airflow_db'
DATABASE = 'airflow'
CREATE_TABLE_SQL = 'CREATE TABLE IF NOT EXISTS {} (table_name ' \
                   'VARCHAR(100), row_count INT);'.format(AIRFLOW_TABLE_NAME)


dag = DAG(
    'airflow-db-table-record-count',
    default_args=default_args,
    catchup=False,
    max_active_runs=1,
    schedule_interval=None
)


def get_tables_from_mysql(**kwargs):
    conn = MySqlHook(mysql_conn_id=MYSQL_CONN_ID, schema='airflow')
    cursor = conn.get_cursor()
    cursor.execute('show tables;')
    records = cursor.fetchall()
    tables_list = [record[0] for record in records]
    if AIRFLOW_TABLE_NAME in tables_list:
        tables_list.remove(AIRFLOW_TABLE_NAME)
    return tables_list


def insert_table_record_counts(**kwargs):
    tables_list = kwargs['ti'].xcom_pull(task_ids='push-tables-list')
    conn = MySqlHook(mysql_conn_id=MYSQL_CONN_ID, schema='airflow')
    cursor = conn.get_cursor()
    print(type(tables_list))
    for table in tables_list:
        insert_statement = "INSERT INTO {} SELECT '{}', count(*) FROM {};"\
            .format(AIRFLOW_TABLE_NAME, table, table)
        cursor.execute(insert_statement)
        cursor.execute('COMMIT;')


push_tables_list_task = PythonOperator(
    task_id='push-tables-list',
    provide_context=True,
    python_callable=get_tables_from_mysql,
    dag=dag
)


table_clean_up_task = MySqlOperator(
    task_id='table-clean-up',
    mysql_conn_id=MYSQL_CONN_ID,
    sql='DROP TABLE IF EXISTS {};'.format(AIRFLOW_TABLE_NAME),
    database=DATABASE,
    dag=dag
)

create_table_task = MySqlOperator(
    task_id='create-mysql-table',
    mysql_conn_id=MYSQL_CONN_ID,
    sql=CREATE_TABLE_SQL,
    database=DATABASE,
    dag=dag
)

insert_table_records_count_task = PythonOperator(
    task_id='insert-tables-record-count',
    provide_context=True,
    python_callable=insert_table_record_counts,
    dag=dag
)

push_tables_list_task >> table_clean_up_task
table_clean_up_task >> create_table_task
create_table_task >> insert_table_records_count_task
