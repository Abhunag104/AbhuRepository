from airflow import DAG
from airflow.contrib.operators.spark_submit_operator\
    import SparkSubmitOperator
from datetime import datetime, timedelta

default_args = {
    'owner': 'airflow',
    'start_date': datetime(2019, 3, 21),
    'retries': 2,
    'retry_delay': timedelta(seconds=60)
}


dag = DAG(
    'trip-data-cleansing',
    default_args=default_args,
    catchup=False,
    max_active_runs=1,
    schedule_interval=None)  # DAG scheduled to run


APPLICATION = "/travix/spark/trip_data_cleansing.py"
INPUT_PATH = "/travix/input/data_cleansing_input.json"
OUTPUT_PATH = "/travix/output/cleaned_data/"
APP_ARGS = ['--input-path', INPUT_PATH, '--output-path', OUTPUT_PATH]

# Keeping Spark Driver/Executor configs to default,
# can be changed based on data
data_cleansing_task = SparkSubmitOperator(
	dag=dag
    application=APPLICATION,
    application_args=APP_ARGS
)