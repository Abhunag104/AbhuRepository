# kafka-realtime-etl
Exploring an end-to-end data pipeline with Kafka  https://www.dezyre.com/hackerday/streaming-etl-in-kafka-with-ksql
