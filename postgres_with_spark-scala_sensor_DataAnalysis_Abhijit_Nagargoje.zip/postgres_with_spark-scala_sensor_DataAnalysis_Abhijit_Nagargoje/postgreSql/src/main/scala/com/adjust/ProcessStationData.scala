package com.adjust
import org.apache.spark
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions.col

object ProcessStationData{

  def main(agrs: Array[String]): Unit = {

    //for running on windows system locally
    //System.setProperty("hadoop.home.dir", "D:\\hadoop-winutils-2.6.0")

    val spark = SparkSession.builder().
      appName("postgres_to_parquet").master("local[*]")
      .getOrCreate()

    spark.sparkContext.setLogLevel("WARN")

    val headerDF = spark.read
      .format("jdbc")
      .option("url", "jdbc:postgresql://192.168.56.116:5432/testdb")
      .option("dbtable", "WEATHER_STATION_HEADER")
      .option("user", "postgres")
      .option("password", "postgres")
      .load()

    val dataDF = spark.read
      .format("jdbc")
      .option("url", "jdbc:postgresql://192.168.56.116:5432/testdb")
      .option("dbtable", "WEATHER_DATA")
      .option("user", "postgres")
      .option("password", "postgres")
      .load()

    dataDF.repartition(col("header_id"))


    //getting all columns except header_id in dataframe
    val resultDF = dataDF.join(headerDF, Seq("header_id"), "inner").
      select("headrec","id","year","month","day","hour","reltime","numlev","p_src","np_src","lat","lon",
        "lvltyp1","lvltyp2","etime","press","pflag","gph","zflag","temp","tflag","rh","dpdp","wdir","wspd")


    // de-duplication of data
    val resultDF_deduplicate = resultDF.dropDuplicates()

    import org.apache.spark.sql.functions.udf

    //UDF to assign range for gph values
    val get_range = (n:Int) => {
      var lower_bound_reminder = 0
      var quotient = 0
      var reminder = 0
      if (n < 0) {
        "-infinity-0"
      }
      else {
        lower_bound_reminder = 1
        quotient = (n / 1000)
        reminder = (n % 1000)
        if (quotient == 0)
          lower_bound_reminder = 0
        if (quotient == 1 && reminder == 0)
          lower_bound_reminder = 0

        if (reminder == 0 && quotient > 0)
          quotient -= 1

        val lower_bound = quotient * 1000 + lower_bound_reminder
        val upper_bound = (quotient + 1) * 1000

        lower_bound.toString + "-" + upper_bound.toString
      }
    }

    val rangeUDF = udf(get_range)

    //adding column for writing data in partition gph (thousands of meters altitude)
    val stored_df = resultDF_deduplicate.withColumn("gph_range", rangeUDF(col("gph")))

    stored_df.write.partitionBy("gph_range").format("parquet")
      .mode("overwrite")
      .save("output/")

  }
}