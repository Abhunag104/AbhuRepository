package com.adjust

import java.io.File
import java.sql.{Connection, DriverManager, ResultSet, SQLException}
import scala.collection.mutable.ListBuffer
import org.apache.commons.lang.time.StopWatch
import java.util.concurrent.Semaphore
import scala.io.Source

object DataLoader {

  var stopwatch = new StopWatch()
  stopwatch.start();

  def main(agrs: Array[String]): Unit = {

    try {

      val connectionString = "jdbc:postgresql://192.168.56.116:5432/testdb?user=postgres&password=postgres"
      val connection = DriverManager.getConnection(connectionString)

      //To get number of cores
      val maxThreads = Runtime.getRuntime.availableProcessors

      val processLock: Semaphore = new Semaphore(maxThreads)

      //Thread creation per file
      val files = getListOfFiles("input/")
      for (filename <- files) {
        var thread = new Thread {
          override def run {
            processRecords(filename.toString, connectionString, connection, processLock)
          }
        }
        processLock.acquire() //acquired semaphore lock for thread
        thread.start
      }
    }
    catch {

      case connectionIssue: Exception => println("failed to process logic please check connection..")
    }
  }

  def getListOfFiles(dir: String): List[File] = {
    val d = new File(dir)
    if (d.exists && d.isDirectory) {
      d.listFiles.filter(_.isFile).toList
    } else {
      List[File]()
    }
  }

  def processRecords(filename: String, connectionString: String,
                       connection: Connection, processLock: Semaphore): Unit = {

    var queries = new ListBuffer[Object]()

    classOf[org.postgresql.Driver]

    val statement = connection.createStatement(ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY)

    try {

      var header_id = ""
      println("processing file....." + filename)

      for (line <- Source.fromFile(filename).getLines) {
        //println(line)

        if (line.trim.matches("#.*")) {
          header_id = line.slice(13, 31).replaceAll("\\s", "_")
          var headrec = line.slice(0, 1)
          var id = line.slice(1, 12)
          var year = line.slice(13, 17).toInt
          var month = line.slice(18, 20).toInt
          var day = line.slice(21, 23).toInt
          var hour = line.slice(24, 26).toInt
          var reltime = line.slice(27, 31).toInt
          var numlev = line.slice(32, 36).replaceAll("\\s", "").toInt
          var p_src = line.slice(37, 45)
          var np_src = line.slice(46, 54)
          var lat = line.slice(56, 62).toInt
          var lon = line.slice(63, 71).toInt

          var prep_header = connection.prepareStatement("INSERT INTO WEATHER_STATION_HEADER " +
            "(header_id,headrec,id,year,month,day,hour,reltime,numlev,p_src,np_src,lat,lon )" +
            "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?) ")
          prep_header.setString(1, header_id)
          prep_header.setString(2, headrec)
          prep_header.setString(3, id)
          prep_header.setInt(4, year)
          prep_header.setInt(5, month)
          prep_header.setInt(6, day)
          prep_header.setInt(7, hour)
          prep_header.setInt(8, reltime)
          prep_header.setInt(9, numlev)
          prep_header.setString(10, p_src)
          prep_header.setString(11, np_src)
          prep_header.setInt(12, lat)
          prep_header.setInt(13, lon)
          //prep_header.executeUpdate

          queries += prep_header

        }
        if (!line.trim.matches("#.*")) {

          //println("data line is ::")
          var lvltyp1 = line.slice(0, 1).replaceAll("\\s", "").toInt
          var lvltyp2 = line.slice(1, 2).replaceAll("\\s", "").toInt
          var etime = line.slice(3, 8).replaceAll("\\s", "").toInt
          var press = line.slice(10, 15).replaceAll("\\s", "").toInt
          var pflag = line.slice(15, 16)
          var gph = line.slice(16, 21).replaceAll("\\s", "").toInt
          var zflag = line.slice(21, 22)
          var temp = line.slice(22, 27).replaceAll("\\s", "").toInt
          var tflag = line.slice(27, 28)
          var rh = line.slice(28, 33).replaceAll("\\s", "").toInt
          var dpdp = line.slice(34, 39).replaceAll("\\s", "").toInt
          var wdir = line.slice(40, 45).replaceAll("\\s", "").toInt
          var wspd = line.slice(46, 51).replaceAll("\\s", "").toInt


          var prep_data = connection.prepareStatement("INSERT INTO WEATHER_DATA " +
            "(header_id,lvltyp1,lvltyp2,etime,press,pflag,gph,zflag,temp,tflag,rh ,dpdp,wdir,wspd)" +
            "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?) ")

          prep_data.setString(1, header_id)
          prep_data.setInt(2, lvltyp1)
          prep_data.setInt(3, lvltyp2)
          prep_data.setInt(4, etime)
          prep_data.setInt(5, press)
          prep_data.setString(6, pflag)
          prep_data.setInt(7, gph)
          prep_data.setString(8, zflag)
          prep_data.setInt(9, temp)
          prep_data.setString(10, tflag)
          prep_data.setInt(11, rh)
          prep_data.setInt(12, dpdp)
          prep_data.setInt(13, wdir)
          prep_data.setInt(14, wspd)

          //prep_data.addBatch()
          //prep_data.execute()

          queries += prep_data


          //running queries on postgres in batch
        }
        if (queries.size > 20000) {

          for (query <- queries) {
            statement.addBatch(query.toString)
          }
          statement.executeBatch
          queries = new ListBuffer[Object]()
        }
      }
      println("processing completed for file " + filename)

    }

    catch {
      case sqlException : SQLException => println("Exception while loading data to Postgres..!")
    }
    finally {
      //closing connection and releasing semaphore lock after a file processed
      connection.close()
      processLock.release()
    }

  }
}